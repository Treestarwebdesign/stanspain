=== Post Parents ===
Contributors: mtekk
Donate link: https://www.paypal.com/cgi-bin/webscr?cmd=_donations&business=FD5XEU783BR8U&lc=US&item_name=Breadcrumb%20NavXT%20Donation&currency_code=USD&bn=PP%2dDonationsBF%3abtn_donateCC_LG%2egif%3aNonHosted
Tags: breadcrumb, breadcrumbs, trail, navigation, menu, widget
Requires at least: 3.4
Tested up to: 3.4.1
Stable tag: 0.0.1
Allows you to set a parent page for posts.

== Description ==

This plugin is desiged to aid users in some unique WordPress layouts with establishing a proper hiearchy for [Breadcrumb NavXT](http://wordpress.org/extend/breadcrumb-navxt "Go to Breadcrumb NavXT's WordPress.org page").
 to follow. It adds a "Parent" metabox to the post edit sidebar on posts.

== Installation ==
1 Upload `post-parents` directory to the `wp-content/plugins/` directory
2 Activate the plugin through the 'Plugins' menu in the WordPress Dashboard

== Changelog ==
= 0.0.1 =
* Initial release